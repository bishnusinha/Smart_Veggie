package com.ibm.bluemix.smartveggie.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.bluemix.smartveggie.dao.VeggieDao;
import com.ibm.bluemix.smartveggie.dto.VeggieDTO;

@Service
public class VeggieServiceImpl implements VeggieService{
	
	@Autowired
	VeggieDao veggieDao;

	public VeggieDTO getAllVegetables(){
		return veggieDao.getAllVegetables();
	}

}
