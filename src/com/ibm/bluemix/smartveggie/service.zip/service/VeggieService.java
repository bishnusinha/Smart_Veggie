package com.ibm.bluemix.smartveggie.service;

import com.ibm.bluemix.smartveggie.dto.VeggieDTO;

public interface VeggieService {

	public VeggieDTO getAllVegetables();
}
