package com.ibm.bluemix.smartveggie.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.bluemix.smartveggie.dao.UserDao;
import com.ibm.bluemix.smartveggie.dto.UserDTO;
import com.mongodb.BasicDBObject;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserDao userDao;
	
	@Override
	public UserDTO getUser(String userName, String password) {
		BasicDBObject dbObj = this.userDao.getUser(userName, password);
		
		UserDTO userDTO = setObjectToDTOMapping(dbObj);
		return userDTO;
	}

	private UserDTO setObjectToDTOMapping(BasicDBObject dbObj) {
		UserDTO userDTO = new UserDTO();
		userDTO.setFirstName(dbObj.getString("firstName"));
		userDTO.setLastName(dbObj.getString("lastName"));
		userDTO.setAddressLine1(dbObj.getString("addressLine1"));
		userDTO.setAddressLine2(dbObj.getString("addressLine2"));
		userDTO.setSex(dbObj.getString("sex"));
		userDTO.setAge(dbObj.getInt("age"));
		userDTO.setCity(dbObj.getString("city"));
		userDTO.setUserTypeCode(dbObj.getString("userType"));
		return userDTO;
	}
	@Override
	public boolean createUser(UserDTO userDTO) {
		BasicDBObject dbObj = this.userDao.createUser(userDTO);
		if(dbObj !=null){
			System.out.println("User Record Created");
			return true;
		}
		else {
			return false;
		}
	}
}
