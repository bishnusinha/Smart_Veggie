package com.ibm.bluemix.smartveggie.service;

import com.ibm.bluemix.smartveggie.dto.UserDTO;
import com.mongodb.BasicDBObject;

public interface UserService {
	public UserDTO getUser(String userName, String password);
	public boolean createUser(UserDTO userDTO);
}
